/**
 * Aimtell Service Worker For Push Notifications
 * Version 1.70.8
 */

var subscriber_uid;

//function to extract information from icon
function getIconVars(iconURL) {
  var vars = {};
  var parts = iconURL.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
  vars[key] = value;
  });
  return vars;
}

self.addEventListener('push', function(event) {  

  //grab the user subscription/registration information 
  event.waitUntil(self.registration.pushManager.getSubscription().then(function(subscription) {
    
    console.log("Checking subscription", subscription)
    console.log("Subscriber", subscriber_uid)
    
    //grab the endpoint, it contains entire url string
    endpoint = subscription.endpoint;

    //url encode the endpoint 
    endpoint = encodeURIComponent(endpoint);

    //pass the endpoint to the server to extract uid and run remaining logic.
    //service worker logic/caching is to unpredictable at this point
    return fetch("https://api.aimtell.com/prod/push/chrome/data/?endpoint="+endpoint).then(function(response) {  
      if (response.status !== 200) {  
        console.log('Looks like there was a problem. Status Code: ' + response.status);  
        throw new Error();  
      }

      // Examine the text in the response  
      return response.json().then(function(data) {  
        if (data.error) {  
          console.error('The API returned an error.', data.error);  
          throw new Error();  
        }  
          
        var title = data.title;  
        var message = data.message;  
        var icon = data.icon;  
        var notificationTag = data.tag;

        return self.registration.showNotification(title, {  
          body: message,  
          icon: icon,  
          tag: notificationTag  
        });  
      });  
    }).catch(function(err) {  
        console.error('Unable to retrieve data', err); 
      }) 
  }))
});

self.addEventListener('notificationclick', function(event) {  
    
  // Force close - android doesn't close the notification when you click on it  
  event.notification.close();

  //grab the icon
  var iconURL = event.notification.icon;

  //check browser version for chrome match
  var chromeVer = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
  chromeVer ? parseInt(chromeVer[2], 10) : false;

  //check to see if potential url has been passed
  if (iconURL.indexOf("?") > -1) {
      var atlink = getIconVars(iconURL)["atlink"]; //grab the web url
      var logid = getIconVars(iconURL)["logid"]; //grab the logid

      //if chrome version 42 or lower, only same domain is allowed
      if(chromeVer && chromeVer < 43){
        
        //since it natively only supports same domain, direct to function
        var webURL = "/?atlink="+atlink+"&logid="+logid; 

        //open window
        return clients.openWindow(webURL);
      }
      else{
        //save click 
        fetch('https://api.aimtell.com/prod/push/click/'+logid, {method: 'post'})

        //make sure its proper link format (sometimes http missing)
        if (!/^https?:\/\//i.test(atlink)) {
            atlink = 'http://' + atlink;
        }
        //open window
        return clients.openWindow(atlink);
      }
      
  }

  
});


self.addEventListener('message', function(event) {

  //just for debugging
  console.log('Handling message event:', event);
  
  switch(event.data.command){
      //service worker receiving registration call
      case 'register':
        
          //store the subscriberID
          subscriber_uid = event.data.uid;

          // event.ports[0] corresponds to the MessagePort that was transferred as part of the controlled page's
          // call to controller.postMessage(). Therefore, event.ports[0].postMessage() will trigger the onmessage
          // handler from the controlled page.
          event.ports[0].postMessage({
            error: null,
            type: "register",
            subscriber_uid: subscriber_uid
          });

        break;

      default:
        // This will be handled by the outer .catch().
        throw 'Unknown command: ' + event.data.command;
  }

});